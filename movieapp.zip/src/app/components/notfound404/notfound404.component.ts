import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notfound404',
  templateUrl: './notfound404.component.html',
  styleUrls: ['./notfound404.component.css']
})
export class Notfound404Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
